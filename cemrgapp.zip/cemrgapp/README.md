Cardiac Electromechanics Research Group
=======================================

This software is distributed WITHOUT ANY WARRANTY or SUPPORT! This project provides a complete CMake-based set-up to get easily started with using [MITK](http://www.mitk.org) and extending it via plug-ins and modules.

Supported Platforms
-------------------

- Linux
- MacOSX 10.9 or newer

Requirements
------------

- CMake 3.2 or newer
- Qt 5.4 (Linux, MacOSX)
- MITK 2016.03.0

We just upgraded to building our application in MITK v2018.04.2

What's new in v2018.04
----------------------

The project template was completely restructured to fit the new extension
mechanism of MITK v2018.04. Here's how it basically works:

1. Clone MITK
2. Clone MITK-ProjectTemplate
3. Configure the MITK superbuild and set the advanced CMake cache variable `MITK_EXTENSION_DIRS` to your working copy of the project template
4. Generate and build the MITK superbuild

The project template is now integrated right into the MITK superbuild and MITK build. Thus you can extend MITK with your own modules, plugins, command-line apps, and external projects without touching the MITK source code. There is no need for a super-superbuild anymore.

Contacts
--------

- http://www.cemrg.co.uk/
- orod.razeghi@kcl.ac.uk

Supported platforms and other requirements
------------------------------------------

See the [MITK documentation](http://docs.mitk.org/2018.04/).
